//
//  roomEscapeApp.swift
//  roomEscape
//
//  Created by student on 4/18/22.
//

import SwiftUI

@main
struct roomEscapeApp: App {
    var body: some Scene {
        WindowGroup {
           ContentView()
        }
    }
}
