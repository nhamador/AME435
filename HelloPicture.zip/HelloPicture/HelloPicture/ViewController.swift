//
//  ViewController.swift
//  HelloPicture
//
//  Created by student on 1/17/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

